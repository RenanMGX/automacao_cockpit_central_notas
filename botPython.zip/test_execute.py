from Entities.extrair_relatorio import ExtrairRelatorio
from Entities.dados import Dados
from pdb import set_trace
import os
from datetime import datetime
from dateutil.relativedelta import relativedelta


if __name__ == "__main__":
    bot = ExtrairRelatorio()
    
    
    d_path = bot.extrair(file_name="test", date_min=(datetime.now() - relativedelta(days=5)), date_max=datetime.now(), fechar_sap_no_final=True)
    dados = Dados(d_path)
    dados.incrementar(file_base_path=r'R:\Automatização Dashboard - Cockpit Central de Notas - Romulo - Contabilidade\#material\base - Copia.json')
    bot.limpar_download_path()
