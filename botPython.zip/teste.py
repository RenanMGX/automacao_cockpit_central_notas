from Entities.dependencies.sap import SAPManipulation

class Sap(SAPManipulation):
    def __init__(self) -> None:
        super().__init__(using_active_conection=True)
        
    @SAPManipulation.start_SAP
    def teste(self):
        import pdb; pdb.set_trace()
        
if __name__ == "__main__":
    Sap().teste()
